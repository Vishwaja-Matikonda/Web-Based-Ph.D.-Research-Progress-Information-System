<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateQualificationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //
        Schema::create('qualifications', function (Blueprint $table) {
           $table->increments('id');
            $table->integer('user_id');

            $table->string('q_organisation');
            $table->string('q_city');
            $table->string('q_state_region');
            $table->string('q_country');
            $table->string('q_department');
            $table->string('q_role_title');
            $table->string('q_url');
            $table->date('q_start_date');
            $table->date('q_end_date');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
        Schema::dropIfExists('qualifications');
    }
}
