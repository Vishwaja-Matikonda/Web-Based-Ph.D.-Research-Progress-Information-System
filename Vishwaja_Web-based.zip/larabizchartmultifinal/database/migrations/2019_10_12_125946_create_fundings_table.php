<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateFundingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //
        Schema::create('fundings', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('user_id');
            $table->string('f_type');
            $table->string('f_sub_type');
            $table->string('f_title_project',60);
            $table->longText('f_description',200);
            $table->double('f_amount',15,2);
            $table->date('f_start_date');
            $table->date('f_end_date');
            $table->string('f_agency_name');
            $table->string('f_agency_city');
            $table->string('f_agency_region');
            $table->string('f_agency_country');
            $table->string('f_grant_number');
            $table->string('f_grant_url');
            $table->string('f_grant_alt_url');
            $table->string('f_grant_relationship');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
        Schema::dropIfExists('fundings');
    }
}
