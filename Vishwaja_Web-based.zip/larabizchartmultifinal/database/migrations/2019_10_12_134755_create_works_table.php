<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateWorksTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //
          Schema::create('works', function (Blueprint $table) {
           $table->increments('id');
            $table->integer('user_id');

            $table->string('w_category');
            $table->string('w_type');
            $table->string('w_subtitle');
            $table->string('w_journal_title');
            $table->date('w_publication_year');
            $table->string('w_citations');
            $table->string('w_identifier_type');
            $table->string('w_identifier_value');
            $table->string('w_identifier_url');
            $table->string('w_identifier_relationship');
            $table->string('w_url');
            $table->string('w_language');
            $table->string('w_country_publication');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
        Schema::dropIfExists('works');
    }
}
