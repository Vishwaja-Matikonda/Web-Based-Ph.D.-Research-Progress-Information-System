<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateEmploymentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //
           Schema::create('employments', function (Blueprint $table) {
           $table->increments('id');
            $table->integer('user_id');

            $table->string('e_organisation');
            $table->string('e_city');
            $table->string('e_state_region');
            $table->string('e_country');
            $table->string('e_department');
            $table->string('e_role_title');
            $table->string('e_url');
            $table->date('e_start_date');
            $table->date('e_end_date');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
        Schema::dropIfExists('employments');
    }
}
