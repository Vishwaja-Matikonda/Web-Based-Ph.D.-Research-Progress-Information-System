<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateServicesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //
         Schema::create('services', function (Blueprint $table) {
           $table->increments('id');
            $table->integer('user_id');

            $table->string('s_organisation');
            $table->string('s_city');
            $table->string('s_state_region');
            $table->string('s_country');
            $table->string('s_department');
            $table->string('s_role_title');
            $table->string('s_url');
            $table->date('s_start_date');
            $table->date('s_end_date');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
        Schema::dropIfExists('services');
    }
}
