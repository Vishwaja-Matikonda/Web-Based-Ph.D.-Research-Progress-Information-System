<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Latest Funding News</div>

                <div class="panel-body">
                    <?php if(count($fundings)): ?>
                        <table class="table table-striped">
                        <tr>
                          <th>Grant No.</th>
                          <th>Type</th>
                          <th>Project Title</th>
                          <th>Amount</th>
                        </tr>
                        <?php $__currentLoopData = $fundings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $funding): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td><?php echo e($funding->f_grant_number); ?></td>
                            <td><?php echo e($funding->f_type); ?></td>
                            <td><?php echo e($funding->f_title_project); ?></td>
                            <td><?php echo e($funding->f_amount); ?></td>
                          </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </table>
                    <?php else: ?>
                      <p>No Fundings Found</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>