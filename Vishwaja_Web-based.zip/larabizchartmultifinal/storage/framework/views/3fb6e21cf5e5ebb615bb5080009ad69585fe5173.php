<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                
              <?php if($users): ?>)
              <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="panel-body">
                    
                   
                      <table class="table table-striped">
                        <tr>
                          <h4>Name: <?php echo e($user->name); ?></h4>
                        </tr>
                        <tr>
                          <h4>Email: <?php echo e($user->email); ?></h4>
                        </tr>
                        <tr><span class="pull-right"><a href="<?php echo e(action('DashboardController@downloadPDF', $user->id)); ?>" class="btn btn-success btn-xs">Download Profile</a></span></tr>
                     
                      </table>
                   
                </div>
                <hr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>