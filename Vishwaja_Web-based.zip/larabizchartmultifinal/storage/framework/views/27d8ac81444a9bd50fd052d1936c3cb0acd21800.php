<?php $__env->startSection('content'); ?>
     <div class="row">
        <h3>Analytics with Static Data-Development is in progress</h3>
    </div>


    <div id="pop_div"></div>

    <?php echo \Lava::render('AreaChart', 'Population', 'pop_div'); ?>

    <div id="perf_div"></div>
    <?php echo \Lava::render('ColumnChart', 'Finances', 'perf_div'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>