<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                

                <div class="panel-body">
                    <h3>Your Listings</h3>
                   
                      <table class="table table-striped">
                        <tr>
                          <h4>Name: <?php echo e($user->name); ?></h4>
                        </tr>
                        <tr>
                          <h4>Email: <?php echo e($user->email); ?></h4>
                        </tr>
                        <tr><span class="pull-right"><a href="<?php echo e(action('DashboardController@downloadPDF', $user->id)); ?>" class="btn btn-success btn-xs">Download Profile</a></span></tr>
                     
                      </table>
                   
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Fundings</div>

                <div class="panel-body">
                    
                    <?php if(count($fundings)): ?>
                      <table class="table table-striped">
                        <tr>
                          <th>Grant No.</th>
                          <th>Type</th>
                          <th>Project Title</th>
                          <th>Amount</th>
                        </tr>
                        <?php $__currentLoopData = $fundings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $funding): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td><?php echo e($funding->f_grant_number); ?></td>
                            <td><?php echo e($funding->f_type); ?></td>
                            <td><?php echo e($funding->f_title_project); ?></td>
                            <td><?php echo e($funding->f_amount); ?></td>
                          </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Qualifications</div>

                <div class="panel-body">
                    
                    <?php if(count($qualifications)): ?>
                      <table class="table table-striped">
                        <tr>
                          <th>Organisation</th>
                          <th>Role/Title</th>
                          <th>From</th>
                          <th>To</th>
                        </tr>
                        <?php $__currentLoopData = $qualifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qualification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td><?php echo e($qualification->q_organisation); ?></td>
                            <td><?php echo e($qualification->q_role_title); ?></td>
                            <td><?php echo e($qualification->q_q_start_date); ?></td>
                            <td><?php echo e($qualification->q_end_date); ?></td>
                          </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Services</div>

                <div class="panel-body">
                    
                    <?php if(count($services)): ?>
                      <table class="table table-striped">
                        <tr>
                          <th>Organisation</th>
                          <th>Role/Title</th>
                          <th>From</th>
                          <th>To</th>
                        </tr>
                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td><?php echo e($service->s_organisation); ?></td>
                            <td><?php echo e($service->s_role_title); ?></td>
                            <td><?php echo e($service->s_start_date); ?></td>
                            <td><?php echo e($service->s_end_date); ?></td>
                            
                          </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Works</div>

                <div class="panel-body">
                    
                    <?php if(count($works)): ?>
                      <table class="table table-striped">
                        <tr>
                          <th>Year</th>
                          <th>Title</th>
                          <th>Category</th>
                          <th>Type</th>
                        </tr>
                        <?php $__currentLoopData = $works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td><?php echo e($work->w_publication_year); ?></td>
                            <td><?php echo e($work->w_journal_title); ?></td>
                            <td><?php echo e($work->w_category); ?></td>
                            <td><?php echo e($work->w_type); ?></td>
                            
                            
                          </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Employments </div>

                <div class="panel-body">
                    
                    <?php if(count($employments)): ?>
                      <table class="table table-striped">
                        <tr>
                          <th>Organisation</th>
                          <th>Role/Title</th>
                          <th>From</th>
                          <th>To</th>
                        </tr>
                        <?php $__currentLoopData = $employments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td><?php echo e($employment->e_organisation); ?></td>
                            <td><?php echo e($employment->e_role_title); ?></td>
                            <td><?php echo e($employment->e_start_date); ?></td>
                            <td><?php echo e($employment->e_end_date); ?></td>
                            
                          </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>