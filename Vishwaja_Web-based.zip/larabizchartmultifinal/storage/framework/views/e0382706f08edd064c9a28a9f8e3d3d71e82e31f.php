<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-8 col-md-offset-2">
        <div class="panel panel-default">
            <div class="panel-heading">Create Work <a href="/dashboard" class="pull-right btn btn-default btn-xs">Go Back</a></div>

            <div class="panel-body">
              <?php echo Form::open(['action' => 'WorksController@store','method' => 'POST']); ?>



               <p>
                  <a class="btn btn-info btn-lg btn-block" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
                    Add Work
                  </a>
                </p>
                <div class="collapse" id="collapseExample">
                  <div class="card card-body">
                    

                    <p><strong>Work Category</strong></p>
                    <?php echo e(Form::select('w_category',['Publication'=>'Publication','Conference'=>'Conference','Intellectual property'=>'Intellectual property','Other'=>'Other'],null,['placeholder'=>'Pick a Category','label'=>'Pick a Category'])); ?>


                    <p><strong>Country</strong></p>
                    <?php echo e(Form::select('w_type',['Book chapter'=>'Book chapter','Book review'=>'Book review','Conference abstract'=>'Conference abstract','Conference paper'=>'Conference paper','Conference poster'=>'Conference poster','Dictionary Entry'=>'Dictionary Entry','thesis'=>'thesis','Encyclopedia entry'=>'Encyclopedia entry','Journal article'=>'Journal article','Journal issue'=>'Journal issue','Magazine article'=>'Magazine article','Manual'=>'Manual','Other'=>'Other'],null,['placeholder'=>'Pick Work type','label'=>'Pick Work type'])); ?>


                    <?php echo e(Form::bsText('w_subtitle','',['placeholder' => 'Subtitle','label'=>'Subtitle'])); ?>


                    <?php echo e(Form::bsText('w_journal_title','',['placeholder' => 'Journal Title','label'=>'Journal Title'])); ?>


                    <p><strong>Start Date</strong></p>
                    <?php echo e(Form::date('w_publication_year','',['placeholder' => 'Publication Year','label'=>'Publication Year'])); ?>


                    <?php echo e(Form::bsText('w_citations','',['placeholder' => 'Citations','label'=>'Citations'])); ?>



                  </div>
                    <br>
                </div>

                <p>
                  <a class="btn btn-info btn-lg btn-block" data-toggle="collapse" href="#collapseExample2" role="button" aria-expanded="false" aria-controls="collapseExample2">
                    Work Identifiers
                  </a>
                </p>
                <div class="collapse" id="collapseExample2">
                  <div class="card card-body">
                    

                    <?php echo e(Form::bsText('w_identifier_type','',['placeholder' => 'Identifier Type','label'=>'Identifier Type'])); ?>


                    <?php echo e(Form::bsText('w_identifier_value','',['placeholder' => 'Identifier Value','label'=>'Identifier Value'])); ?>


                    <?php echo e(Form::bsText('w_identifier_url','',['placeholder' => 'Identifier URL','label'=>'Identifier URL'])); ?>


                    <p><strong>Relationship</strong></p>
                    <?php echo e(Form::select('w_identifier_relationship',['Self'=>'Self','Part Of'=>'Part Of','Version Of'=>'Version Of'],null,['placeholder'=>'Select Relationship','label'=>'Select Relationship'])); ?>


                    <?php echo e(Form::bsText('w_url','',['placeholder' => 'URL','label'=>'URL'])); ?>


                    <p><strong>Language used in this form</strong></p>
                    <?php echo e(Form::select('w_language',['Chinese'=>'Chinese','English'=>'English','Telugu'=>'Telugu','Hindi'=>'Hindi','Spanish'=>'Spanish','Russian'=>'Russian','Bengali'=>'Bengali','Arabic'=>'Arabic','Other'=>'Other'],null,['placeholder'=>'Pick a Category','label'=>'Pick a Category'])); ?>


                    <p><strong>Country Of Publication</strong></p>
                    <?php echo e(Form::select('w_country_publication',['India'=>'India','USA'=>'USA','England'=>'England','South Africa'=>'South Africa','Russia'=>'Russia','Malaysia'=>'Malaysia','Other'=>'Other'],null,['placeholder'=>'Pick a Category','label'=>'Pick a Category'])); ?>


                  </div>
                    <br>
                </div>

                
                


                <?php echo e(Form::bsSubmit('submit')); ?>

              <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>