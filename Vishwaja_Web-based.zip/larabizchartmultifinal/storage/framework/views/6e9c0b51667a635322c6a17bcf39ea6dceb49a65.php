<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-8 col-md-offset-2">
        <div class="panel panel-default">
            <div class="panel-heading">Edit Qualification <a href="/dashboard" class="pull-right btn btn-default btn-xs">Go Back</a></div>

            <div class="panel-body">
              <?php echo Form::open(['action' => ['QualificationsController@update', $qualification->id],'method' => 'POST']); ?>



                    <?php echo e(Form::bsText('q_organisation',$qualification->q_organisation,['placeholder' => 'Organisation','label'=>'Organisation'])); ?>


                    <?php echo e(Form::bsText('q_city',$qualification->q_city,['placeholder' => 'City','label'=>'City'])); ?>


                    <?php echo e(Form::bsText('q_state_region',$qualification->q_state_region,['placeholder' => 'State/Region','label'=>'State/Region'])); ?>


                    <p><strong>Country</strong></p>
                    <?php echo e(Form::select('q_country',['India'=>'India','USA'=>'USA','England'=>'England','South Africa'=>'South Africa','Russia'=>'Russia','Malaysia'=>'Malaysia','Other'=>'Other'],$qualification->q_country,['placeholder'=>'Country','label'=>'Country'])); ?>


                    <?php echo e(Form::bsText('q_department',$qualification->q_department,['placeholder' => 'Department','label'=>'Department'])); ?>


                    <?php echo e(Form::bsText('q_role_title',$qualification->q_role_title,['placeholder' => 'Role/Title','label'=>'Role/Title'])); ?>


                    <?php echo e(Form::bsText('q_url',$qualification->q_url,['placeholder' => 'URL','label'=>'URL'])); ?>


                    <p><strong>Start Date</strong></p>
                    <?php echo e(Form::date('q_start_date',$qualification->q_start_date,['placeholder' => 'Start Date','label'=>'Start Date'])); ?>


                    <p><strong>End Date</strong></p>
                    <?php echo e(Form::date('q_end_date',$qualification->q_end_date,['placeholder' => 'End Date','label'=>'End Date'])); ?>




                <?php echo e(Form::hidden('_method', 'PUT')); ?>

                <?php echo e(Form::bsSubmit('submit')); ?>

              <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>