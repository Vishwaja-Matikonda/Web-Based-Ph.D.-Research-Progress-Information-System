<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Employment;

class EmploymentsController extends Controller
{

    public function __construct(){
      $this->middleware('auth', ['except' => ['index', 'show']]);
    }
    /**
     * Display a employment of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $employments = Employment::orderBy('created_at', 'desc')->get();
        return view('employments')->with('employments', $employments);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('createemployment');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
          'e_organisation' => 'required',
          'e_role_title' => 'required'
        ]);

        // Create employment
        $employment = new Employment;

        $employment->e_organisation = $request->input('e_organisation');
        $employment->e_city = $request->input('e_city');
        $employment->e_state_region = $request->input('e_state_region');
        $employment->e_country = $request->input('e_country');
        $employment->e_department = $request->input('e_department');
        $employment->e_role_title = $request->input('e_role_title');
        $employment->e_url = $request->input('e_url');
        $employment->e_start_date = $request->input('e_start_date');
        $employment->e_end_date = $request->input('e_end_date');


        $employment->user_id = auth()->user()->id;

        $employment->save();

        return redirect('/dashboard')->with('success', 'employment Added');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
      $employment = Employment::find($id);
      return view('showemployment')->with('employment', $employment);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $employment = Employment::find($id);
        return view('editemployment')->with('employment', $employment);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
      $this->validate($request, [
        'e_organisation' => 'required',
        'e_role_title' => 'required'
      ]);

      // Create employment
      $employment = Employment::find($id);

        $employment->e_organisation = $request->input('e_organisation');
        $employment->e_city = $request->input('e_city');
        $employment->e_state_region = $request->input('e_state_region');
        $employment->e_country = $request->input('e_country');
        $employment->e_department = $request->input('e_department');
        $employment->e_role_title = $request->input('e_role_title');
        $employment->e_url = $request->input('e_url');
        $employment->e_start_date = $request->input('e_start_date');
        $employment->e_end_date = $request->input('e_end_date');

      $employment->save();

      return redirect('/dashboard')->with('success', 'employment Updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $employment = Employment::find($id);
        $employment->delete();

        return redirect('/dashboard')->with('success', 'employment Removed');
    }
}