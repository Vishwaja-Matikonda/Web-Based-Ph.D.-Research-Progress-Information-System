<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Qualification;

class QualificationsController extends Controller
{

    public function __construct(){
      $this->middleware('auth', ['except' => ['index', 'show']]);
    }
    /**
     * Display a qualification of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $qualifications = Qualification::orderBy('created_at', 'desc')->get();
        return view('qualifications')->with('qualifications', $qualifications);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('createqualification');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
          'q_organisation' => 'required',
          'q_role_title' => 'required'
        ]);

        // Create qualification
        $qualification = new Qualification;

        $qualification->q_organisation = $request->input('q_organisation');
        $qualification->q_city = $request->input('q_city');
        $qualification->q_state_region = $request->input('q_state_region');
        $qualification->q_country = $request->input('q_country');
        $qualification->q_department = $request->input('q_department');
        $qualification->q_role_title = $request->input('q_role_title');
        $qualification->q_url = $request->input('q_url');
        $qualification->q_start_date = $request->input('q_start_date');
        $qualification->q_end_date = $request->input('q_end_date');


        $qualification->user_id = auth()->user()->id;

        $qualification->save();

        return redirect('/dashboard')->with('success', 'qualification Added');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
      $qualification = Qualification::find($id);
      return view('showqualification')->with('qualification', $qualification);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $qualification = Qualification::find($id);
        return view('editqualification')->with('qualification', $qualification);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
      $this->validate($request, [
        'q_organisation' => 'required',
        'q_role_title' => 'required'
      ]);

      // Create qualification
      $qualification = Qualification::find($id);

        $qualification->q_organisation = $request->input('q_organisation');
        $qualification->q_city = $request->input('q_city');
        $qualification->q_state_region = $request->input('q_state_region');
        $qualification->q_country = $request->input('q_country');
        $qualification->q_department = $request->input('q_department');
        $qualification->q_role_title = $request->input('q_role_title');
        $qualification->q_url = $request->input('q_url');
        $qualification->q_start_date = $request->input('q_start_date');
        $qualification->q_end_date = $request->input('q_end_date');

      $qualification->user_id = auth()->user()->id;

      $qualification->save();

      return redirect('/dashboard')->with('success', 'qualification Updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $qualification = Qualification::find($id);
        $qualification->delete();

        return redirect('/dashboard')->with('success', 'qualification Removed');
    }
}
