<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Listing;
use App\Funding;
use App\Qualification;
use App\Service;
use App\Work;
use App\Employment;
use Khill\Lavacharts\Lavacharts;
use PDF;

class DashboardController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $user_id = auth()->user()->id;

        $user = User::find($user_id);

        return view('dashboard')->with('listings', $user->listings)
                                ->with('fundings', $user->fundings)
                                ->with('qualifications', $user->qualifications)
                                ->with('services', $user->services)
                                ->with('works', $user->works)
                                ->with('employments', $user->employments);
    }
 
    /************
    ****/
     public function profile()
    {
        $user_id = auth()->user()->id;

        $user = User::find($user_id);

        return view('profile')->with('listings', $user->listings)
                              ->with('fundings', $user->fundings)
                              ->with('qualifications', $user->qualifications)
                              ->with('services', $user->services)
                              ->with('works', $user->works)
                              ->with('employments', $user->employments)
                              ->with('user', $user);
    }


    /******
    ****/
    public function chart()
    {
        $population = \Lava::DataTable();

        $population->addDateColumn('Year')
                   ->addNumberColumn('Number of People')
                   ->addRow(['2006', 623452])
                   ->addRow(['2007', 685034])
                   ->addRow(['2008', 716845])
                   ->addRow(['2009', 757254])
                   ->addRow(['2010', 778034])
                   ->addRow(['2011', 792353])
                   ->addRow(['2012', 839657])
                   ->addRow(['2013', 842367])
                   ->addRow(['2014', 873490]);

        $areachart =\Lava::AreaChart('Population', $population, [
            'title' => 'Population Growth',
            'legend' => [
                'position' => 'in'
            ]
        ]);


        $finances = \Lava::DataTable();

        $finances->addDateColumn('Year')
                 ->addNumberColumn('Sales')
                 ->addNumberColumn('Expenses')
                 ->setDateTimeFormat('Y')
                 ->addRow(['2004', 1000, 400])
                 ->addRow(['2005', 1170, 460])
                 ->addRow(['2006', 660, 1120])
                 ->addRow(['2007', 1030, 54]);

       $columnchart = \Lava::ColumnChart('Finances', $finances, [
            'title' => 'Company Performance',
            'titleTextStyle' => [
                'color'    => '#eb6b2c',
                'fontSize' => 14
            ]
        ]);

        return view('chart')->with('areachart', $areachart)->with('columnchart',$columnchart);

    }

     public function chart2()
    {
        $population = \Lava::DataTable();

        $population->addDateColumn('Year')
                   ->addNumberColumn('Number of People')
                   ->addRow(['2006', 623452])
                   ->addRow(['2007', 685034])
                   ->addRow(['2008', 716845])
                   ->addRow(['2009', 757254])
                   ->addRow(['2010', 778034])
                   ->addRow(['2011', 792353])
                   ->addRow(['2012', 839657])
                   ->addRow(['2013', 842367])
                   ->addRow(['2014', 873490]);

        $areachart =\Lava::AreaChart('Population', $population, [
            'title' => 'Population Growth',
            'legend' => [
                'position' => 'in'
            ]
        ]);


        $finances = \Lava::DataTable();

        $finances->addDateColumn('Year')
                 ->addNumberColumn('Sales')
                 ->addNumberColumn('Expenses')
                 ->setDateTimeFormat('Y')
                 ->addRow(['2004', 1000, 400])
                 ->addRow(['2005', 1170, 460])
                 ->addRow(['2006', 660, 1120])
                 ->addRow(['2007', 1030, 54]);

       $columnchart = \Lava::ColumnChart('Finances', $finances, [
            'title' => 'Company Performance',
            'titleTextStyle' => [
                'color'    => '#eb6b2c',
                'fontSize' => 14
            ]
        ]);

        return view('chart')->with('areachart', $areachart)->with('columnchart',$columnchart);

    }

      public function downloadPDF($id){
      $user = User::find($id);
      $listings=$user->listings;
      $fundings= $user->fundings;
      $qualifications= $user->qualifications;
      $services= $user->services;
      $works= $user->works;
      $employments= $user->employments;

      $pdf = PDF::loadView('pdf', compact('user','listings','fundings','qualifications','services','works','employments'));
      return $pdf->download($user->name.'.pdf');

    }
    public function admin(){
        $users = User::orderBy('created_at', 'desc')->get();
        return view('admin')->with('users', $users);
      
    }


}
