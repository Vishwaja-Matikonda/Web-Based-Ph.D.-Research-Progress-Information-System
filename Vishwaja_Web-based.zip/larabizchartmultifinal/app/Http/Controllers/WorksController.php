<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Work;

class WorksController extends Controller
{

    public function __construct(){
      $this->middleware('auth', ['except' => ['index', 'show']]);
    }
    /**
     * Display a work of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $works = Work::orderBy('created_at', 'desc')->get();
        return view('works')->with('works', $works);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('creatework');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
          'w_category' => 'required',
          'w_type' => 'required'
        ]);

        // Create work
        $work = new Work;

        $work->w_category = $request->input('w_category');
        $work->w_type = $request->input('w_type');
        $work->w_subtitle = $request->input('w_subtitle');
        $work->w_journal_title = $request->input('w_journal_title');
        $work->w_publication_year = $request->input('w_publication_year');
        $work->w_citations = $request->input('w_citations');
        $work->w_identifier_type = $request->input('w_identifier_type');
        $work->w_identifier_value = $request->input('w_identifier_value');
        $work->w_identifier_url = $request->input('w_identifier_url');
        $work->w_identifier_relationship = $request->input('w_identifier_relationship');
        $work->w_url = $request->input('w_url');
        $work->w_language = $request->input('w_language');
        $work->w_country_publication = $request->input('w_country_publication');

        $work->user_id = auth()->user()->id;

        $work->save();

        return redirect('/dashboard')->with('success', 'work Added');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
      $work = Work::find($id);
      return view('showwork')->with('work', $work);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $work = Work::find($id);
        return view('editwork')->with('work', $work);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
      $this->validate($request, [
        'w_category' => 'required',
        'w_type' => 'required'
      ]);

      // Create work
      $work = Work::find($id);
      $work->w_name = $request->input('name');
      $work->w_website = $request->input('website');
      $work->w_email = $request->input('email');
      $work->w_phone = $request->input('phone');
      $work->w_address = $request->input('address');
      $work->w_bio = $request->input('bio');
      $work->user_id = auth()->user()->id;

      $work->save();

      return redirect('/dashboard')->with('success', 'work Updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $work = Work::find($id);
        $work->delete();

        return redirect('/dashboard')->with('success', 'work Removed');
    }
}
