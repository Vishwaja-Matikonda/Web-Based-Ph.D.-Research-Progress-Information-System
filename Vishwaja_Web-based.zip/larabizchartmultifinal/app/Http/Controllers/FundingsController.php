<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Funding;

class FundingsController extends Controller
{

    public function __construct(){
      $this->middleware('auth', ['except' => ['index', 'show']]);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $fundings = Funding::orderBy('created_at', 'desc')->get();
        return view('fundings')->with('fundings', $fundings);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('createfunding');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
          'f_type' => 'required',
          'f_title_project' => 'required'
        ]);

        // Create funding
        $funding = new Funding;
        $funding->f_type = $request->input('f_type');
        $funding->f_sub_type = $request->input('f_sub_type');
        $funding->f_title_project = $request->input('f_title_project');
        $funding->f_description = $request->input('f_description');
        $funding->f_amount = $request->input('f_amount');
        $funding->f_start_date = $request->input('f_start_date');
        $funding->f_end_date = $request->input('f_end_date');

        $funding->f_agency_name = $request->input('f_agency_name');
        $funding->f_agency_city = $request->input('f_agency_city');
        $funding->f_agency_region = $request->input('f_agency_region');
        $funding->f_agency_country = $request->input('f_agency_country');
        $funding->f_grant_number = $request->input('f_grant_number');
        $funding->f_grant_url = $request->input('f_grant_url');
        $funding->f_grant_alt_url = $request->input('f_grant_alt_url');
        $funding->f_grant_relationship = $request->input('f_grant_relationship');

        $funding->user_id = auth()->user()->id;

        $funding->save();

        return redirect('/dashboard')->with('success', 'Funding Added');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
      $funding = Funding::find($id);
      return view('showfunding')->with('funding', $funding);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $funding = Funding::find($id);
        return view('editfunding')->with('funding', $funding);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
      $this->validate($request, [
        'f_type' => 'required',
        'f_description' => 'required'
      ]);

      // Create listing
      $funding =Funding::find($id);

        $funding->f_type = $request->input('f_type');
        $funding->f_sub_type = $request->input('f_sub_type');
        $funding->f_title_project = $request->input('f_title_project');
        $funding->f_description = $request->input('f_description');
        $funding->f_amount = $request->input('f_amount');
        $funding->f_start_date = $request->input('f_start_date');
        $funding->f_end_date = $request->input('f_end_date');

        $funding->f_agency_name = $request->input('f_agency_name');
        $funding->f_agency_city = $request->input('f_agency_city');
        $funding->f_agency_region = $request->input('f_agency_region');
        $funding->f_agency_country = $request->input('f_agency_country');
        $funding->f_grant_number = $request->input('f_grant_number');
        $funding->f_grant_url = $request->input('f_grant_url');
        $funding->f_grant_alt_url = $request->input('f_grant_alt_url');
        $funding->f_grant_relationship = $request->input('f_grant_relationship');

      $funding->user_id = auth()->user()->id;

      $funding->save();

      return redirect('/dashboard')->with('success', 'Funding Updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $funding = Funding::find($id);
        $funding->delete();

        return redirect('/dashboard')->with('success', 'Funding Removed');
    }
}