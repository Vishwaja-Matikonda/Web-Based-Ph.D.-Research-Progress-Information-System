<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Service;

class ServicesController extends Controller
{

    public function __construct(){
      $this->middleware('auth', ['except' => ['index', 'show']]);
    }
    /**
     * Display a service of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $services = Service::orderBy('created_at', 'desc')->get();
        return view('services')->with('services', $services);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('createservice');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
          's_organisation' => 'required',
          's_role_title' => 'required'
        ]);

        // Create service
        $service = new Service;

        $service->s_organisation = $request->input('s_organisation');
        $service->s_city = $request->input('s_city');
        $service->s_state_region = $request->input('s_state_region');
        $service->s_country = $request->input('s_country');
        $service->s_department = $request->input('s_department');
        $service->s_role_title = $request->input('s_role_title');
        $service->s_url = $request->input('s_url');
        $service->s_start_date = $request->input('s_start_date');
        $service->s_end_date = $request->input('s_end_date');

        $service->user_id = auth()->user()->id;

        $service->save();

        return redirect('/dashboard')->with('success', 'service Added');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
      $service = Service::find($id);
      return view('showservice')->with('service', $service);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $service = Service::find($id);
        return view('editservice')->with('service', $service);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
      $this->validate($request, [
        's_organisation' => 'required',
        's_role_title' => 'required'
      ]);

      // Create service
      $service = Service::find($id);

        $service->s_organisation = $request->input('s_organisation');
        $service->s_city = $request->input('s_city');
        $service->s_state_region = $request->input('s_state_region');
        $service->s_country = $request->input('s_country');
        $service->s_department = $request->input('s_department');
        $service->s_role_title = $request->input('s_role_title');
        $service->s_url = $request->input('s_url');
        $service->s_start_date = $request->input('s_start_date');
        $service->s_end_date = $request->input('s_end_date');

      $service->user_id = auth()->user()->id;

      $service->save();

      return redirect('/dashboard')->with('success', 'service Updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $service = Service::find($id);
        $service->delete();

        return redirect('/dashboard')->with('success', 'service Removed');
    }
}
