<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    // Add One to many relationship
    public function listings(){
      return $this->hasMany('App\Listing');
    }
    //Funding
    public function fundings(){
      return $this->hasMany('App\Funding');
    }
    //Qualification
    public function qualifications(){
      return $this->hasMany('App\Qualification');
    }
    //Service
    public function services(){
      return $this->hasMany('App\Service');
    }
    //Works
    public function works(){
      return $this->hasMany('App\Work');
    }
     //Employment
    public function employments(){
      return $this->hasMany('App\Employment');
    }
}
