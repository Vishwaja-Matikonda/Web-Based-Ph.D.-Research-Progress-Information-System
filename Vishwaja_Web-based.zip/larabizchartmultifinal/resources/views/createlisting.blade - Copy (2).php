@extends('layouts.app')

@section('content')
<div class="row">
    <div class="col-md-8 col-md-offset-2">
        <div class="panel panel-default">
            <div class="panel-heading">Create Listing <a href="/dashboard" class="pull-right btn btn-default btn-xs">Go Back</a></div>

            <div class="panel-body">
              {!!Form::open(['action' => 'ListingsController@store','method' => 'POST'])!!}

                 <p>
                  <a class="btn btn-info btn-lg btn-block" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
                    Add Employment
                  </a>
                </p>
                <div class="collapse" id="collapseExample">
                  <div class="card card-body">
                    {{Form::bsText('name','',['placeholder' => 'Company Name'])}}
                    {{Form::bsText('website','',['placeholder' => 'Company Website'])}}
                    </div>
                </div>

                <p>
                  <a class="btn btn-info btn-lg btn-block" data-toggle="collapse" href="#collapseExample2" role="button" aria-expanded="false" aria-controls="collapseExample">
                    Add Qualification
                  </a>
                </p>
                <div class="collapse" id="collapseExample2">
                  <div class="card card-body">
                    {{Form::bsText('email','',['placeholder' => 'Contact Email'])}}
                    {{Form::bsText('phone','',['placeholder' => 'Contact Phone'])}}
                    </div>
                </div>

                 <p>
                  <a class="btn btn-info btn-lg btn-block" data-toggle="collapse" href="#collapseExample3" role="button" aria-expanded="false" aria-controls="collapseExample">
                    Add invited position
                  </a>
                </p>
                <div class="collapse" id="collapseExample3">
                  <div class="card card-body">
                    {{Form::bsText('address','',['placeholder' => 'Business Address'])}}
                    {{Form::bsTextArea('bio','',['placeholder' => 'About This Business'])}}
                    </div>
                </div>
                
                
                
                {{Form::bsSubmit('submit')}}
              {!! Form::close() !!}
            </div>
        </div>
    </div>
</div>
@endsection
