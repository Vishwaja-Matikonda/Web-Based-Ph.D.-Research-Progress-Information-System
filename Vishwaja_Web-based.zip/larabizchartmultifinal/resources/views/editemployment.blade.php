@extends('layouts.app')

@section('content')
<div class="row">
    <div class="col-md-8 col-md-offset-2">
        <div class="panel panel-default">
            <div class="panel-heading">Edit Employment <a href="/dashboard" class="pull-right btn btn-default btn-xs">Go Back</a></div>

            <div class="panel-body">
              {!!Form::open(['action' => ['EmploymentsController@update', $employment->id],'method' => 'POST'])!!}


                {{Form::bsText('e_organisation',$employment->e_organisation,['placeholder' => 'Organisation','label'=>'Organisation'])}}

                {{Form::bsText('e_city',$employment->e_city,['placeholder' => 'City','label'=>'City'])}}

                {{Form::bsText('e_state_region',$employment->e_state_region,['placeholder' => 'State/Region','label'=>'State/Region'])}}

                <p><strong>Country</strong></p>
                {{Form::select('e_country',['India'=>'India','USA'=>'USA','England'=>'England','South Africa'=>'South Africa','Russia'=>'Russia','Malaysia'=>'Malaysia','Other'=>'Other'],$employment->e_country,['placeholder'=>'Country','label'=>'Country'])}}

                {{Form::bsText('e_department',$employment->e_department,['placeholder' => 'Department','label'=>'Department'])}}

                {{Form::bsText('e_role_title',$employment->e_role_title,['placeholder' => 'Role/Title','label'=>'Role/Title'])}}

                {{Form::bsText('e_url',$employment->e_url,['placeholder' => 'URL','label'=>'URL'])}}

                <p><strong>Start Date</strong></p>
                {{Form::date('e_start_date',$employment->e_start_date,['placeholder' => 'Start Date','label'=>'Start Date'])}}

                <p><strong>End Date</strong></p>
                {{Form::date('e_end_date',$employment->e_end_date,['placeholder' => 'End Date','label'=>'End Date'])}}



                {{Form::hidden('_method', 'PUT')}}
                {{Form::bsSubmit('submit')}}
              {!! Form::close() !!}
            </div>
        </div>
    </div>
</div>
@endsection
