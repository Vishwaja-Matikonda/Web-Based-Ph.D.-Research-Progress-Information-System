@extends('layouts.app')

@section('content')
<div class="row">
    <div class="col-md-8 col-md-offset-2">
        <div class="panel panel-default">
            <div class="panel-heading">Create Employment <a href="/dashboard" class="pull-right btn btn-default btn-xs">Go Back</a></div>

            <div class="panel-body">
              {!!Form::open(['action' => 'EmploymentsController@store','method' => 'POST'])!!}


                {{Form::bsText('e_organisation','',['placeholder' => 'Organisation','label'=>'Organisation'])}}

                {{Form::bsText('e_city','',['placeholder' => 'City','label'=>'City'])}}

                {{Form::bsText('e_state_region','',['placeholder' => 'State/Region','label'=>'State/Region'])}}

                <p><strong>Country</strong></p>
                {{Form::select('e_country',['India'=>'India','USA'=>'USA','England'=>'England','South Africa'=>'South Africa','Russia'=>'Russia','Malaysia'=>'Malaysia','Other'=>'Other'],null,['placeholder'=>'Country','label'=>'Country'])}}

                {{Form::bsText('e_department','',['placeholder' => 'Department','label'=>'Department'])}}

                {{Form::bsText('e_role_title','',['placeholder' => 'Role/Title','label'=>'Role/Title'])}}

                {{Form::bsText('e_url','',['placeholder' => 'URL','label'=>'URL'])}}

                <p><strong>Start Date</strong></p>
                {{Form::date('e_start_date','',['placeholder' => 'Start Date','label'=>'Start Date'])}}

                <p><strong>End Date</strong></p>
                {{Form::date('e_end_date','',['placeholder' => 'End Date','label'=>'End Date'])}}



                {{Form::bsSubmit('submit')}}
              {!! Form::close() !!}
            </div>
        </div>
    </div>
</div>
@endsection
