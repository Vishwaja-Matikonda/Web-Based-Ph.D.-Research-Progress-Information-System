@extends('layouts.app')

@section('content')
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                

                <div class="panel-body">
                    <h3>Your Listings</h3>
                   
                      <table class="table table-striped">
                        <tr>
                          <h4>Name: {{$user->name}}</h4>
                        </tr>
                        <tr>
                          <h4>Email: {{$user->email}}</h4>
                        </tr>
                        <tr><span class="pull-right"><a href="{{action('DashboardController@downloadPDF', $user->id)}}" class="btn btn-success btn-xs">Download Profile</a></span></tr>
                     
                      </table>
                   
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Fundings</div>

                <div class="panel-body">
                    
                    @if(count($fundings))
                      <table class="table table-striped">
                        <tr>
                          <th>Grant No.</th>
                          <th>Type</th>
                          <th>Project Title</th>
                          <th>Amount</th>
                        </tr>
                        @foreach($fundings as $funding)
                          <tr>
                            <td>{{$funding->f_grant_number}}</td>
                            <td>{{$funding->f_type}}</td>
                            <td>{{$funding->f_title_project}}</td>
                            <td>{{$funding->f_amount}}</td>
                          </tr>
                        @endforeach
                      </table>
                    @endif
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Qualifications</div>

                <div class="panel-body">
                    
                    @if(count($qualifications))
                      <table class="table table-striped">
                        <tr>
                          <th>Organisation</th>
                          <th>Role/Title</th>
                          <th>From</th>
                          <th>To</th>
                        </tr>
                        @foreach($qualifications as $qualification)
                          <tr>
                            <td>{{$qualification->q_organisation}}</td>
                            <td>{{$qualification->q_role_title}}</td>
                            <td>{{$qualification->q_q_start_date}}</td>
                            <td>{{$qualification->q_end_date}}</td>
                          </tr>
                        @endforeach
                      </table>
                    @endif
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Services</div>

                <div class="panel-body">
                    
                    @if(count($services))
                      <table class="table table-striped">
                        <tr>
                          <th>Organisation</th>
                          <th>Role/Title</th>
                          <th>From</th>
                          <th>To</th>
                        </tr>
                        @foreach($services as $service)
                          <tr>
                            <td>{{$service->s_organisation}}</td>
                            <td>{{$service->s_role_title}}</td>
                            <td>{{$service->s_start_date}}</td>
                            <td>{{$service->s_end_date}}</td>
                            
                          </tr>
                        @endforeach
                      </table>
                    @endif
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Works</div>

                <div class="panel-body">
                    
                    @if(count($works))
                      <table class="table table-striped">
                        <tr>
                          <th>Year</th>
                          <th>Title</th>
                          <th>Category</th>
                          <th>Type</th>
                        </tr>
                        @foreach($works as $work)
                          <tr>
                            <td>{{$work->w_publication_year}}</td>
                            <td>{{$work->w_journal_title}}</td>
                            <td>{{$work->w_category}}</td>
                            <td>{{$work->w_type}}</td>
                            
                            
                          </tr>
                        @endforeach
                      </table>
                    @endif
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Employments </div>

                <div class="panel-body">
                    
                    @if(count($employments))
                      <table class="table table-striped">
                        <tr>
                          <th>Organisation</th>
                          <th>Role/Title</th>
                          <th>From</th>
                          <th>To</th>
                        </tr>
                        @foreach($employments as $employment)
                          <tr>
                            <td>{{$employment->e_organisation}}</td>
                            <td>{{$employment->e_role_title}}</td>
                            <td>{{$employment->e_start_date}}</td>
                            <td>{{$employment->e_end_date}}</td>
                            
                          </tr>
                        @endforeach
                      </table>
                    @endif
                </div>
            </div>
        </div>
    </div>

@endsection
