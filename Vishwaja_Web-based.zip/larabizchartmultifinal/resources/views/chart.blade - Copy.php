@extends('layouts.app')

@section('content')
    <div id="pop_div"></div>

    @areachart('Population', 'pop_div')
@endsection
