@extends('layouts.app')

@section('content')
<div class="row">
    <div class="col-md-8 col-md-offset-2">
        <div class="panel panel-default">
            <div class="panel-heading">Add Funding <a href="/dashboard" class="pull-right btn btn-default btn-xs">Go Back</a></div>

            <div class="panel-body">
              {!!Form::open(['action' => 'FundingsController@store','method' => 'POST'])!!}


                <p>
                  <a class="btn btn-info btn-lg btn-block" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
                    Funding
                  </a>
                </p>
                <div class="collapse" id="collapseExample">
                  <div class="card card-body">
                    <p><strong>Funding Type</strong></p>
                    {{Form::select('f_type',['Scholrships&Fellowships'=>'Scholrships&Fellowships','Seed funding'=>'Seed funding','Proect funding'=>'Proect funding','Centre funding'=>'Centre funding','Prizes&Awards'=>'Prizes&Awards','Other'=>'Other'],null,['placeholder'=>'Pick funding type','label'=>'Funding Type'])}}
                    
                    {{Form::bsText('f_sub_type','',['placeholder' => 'Funding Sub type','label'=>'Funding Sub Type'])}}
                    {{Form::bsText('f_title_project','',['placeholder' => 'Funding Project title','label'=>'Funding Project title'])}}
                    {{Form::bsTextArea('f_description','',['placeholder' => 'Funding Project Description','label'=>'Funding Project Description'])}}
                     {{Form::bsText('f_amount','',['placeholder' => 'Funding Amount','label'=>'Funding Amount'])}}
                     <p><strong>Funding Start Date</strong></p>
                     {{Form::date('f_start_date','',['placeholder' => 'Funding Start Date','label'=>'Funding Start Date'])}}
                      <p><strong>Funding End Date</strong></p>
                      {{Form::date('f_end_date','',['placeholder' => 'Funding End Date','label'=>'Funding End Date'])}}
                    </div>
                    <br>
                </div>


                <p>
                  <a class="btn btn-info btn-lg btn-block" data-toggle="collapse" href="#collapseExample2" role="button" aria-expanded="false" aria-controls="collapseExample">
                    Funding Agency 
                  </a>
                </p>
                <div class="collapse" id="collapseExample2">
                  <div class="card card-body">
                    {{Form::bsText('f_agency_name','',['placeholder' => 'Funding Agency Name'])}}
                    {{Form::bsText('f_agency_city','',['placeholder' => 'Funding Agency City'])}}
                    {{Form::bsText('f_agency_region','',['placeholder' => 'Funding Agency Region'])}}
                    <p><strong>Funding Type</strong></p>
                    {{Form::select('f_agency_country',['India'=>'India','USA'=>'USA','England'=>'England','South Africa'=>'South Africa','Russia'=>'Russia','Malaysia'=>'Malaysia','Other'=>'Other'],null,['placeholder'=>'Select country','label'=>'Funding Agency country'])}}
                    
                    </div>
                    <br>
                </div>

                 <p>
                  <a class="btn btn-info btn-lg btn-block" data-toggle="collapse" href="#collapseExample3" role="button" aria-expanded="false" aria-controls="collapseExample">
                    Grant Number
                  </a>
                </p>
                <div class="collapse" id="collapseExample3">
                  <div class="card card-body">
                    {{Form::bsText('f_grant_number','',['placeholder' => 'Funding Grant Number'])}}
                    {{Form::bsText('f_grant_url','',['placeholder' => 'Funding Grant URL'])}}
                    {{Form::bsText('f_grant_alt_url','',['placeholder' => 'Funding Grant Alternative URL'])}}
                     <p><strong>Relationship</strong></p>
                    {{Form::select('f_grant_relationship',['Self'=>'Self','Part Of'=>'Part Of'],null,['placeholder'=>'Select Relationship','label'=>'Funding Grant relationship'])}}
                    
                    </div>
                    <br>
                </div>
                


              {{Form::bsSubmit('submit')}}
              {!! Form::close() !!}
            </div>
        </div>
    </div>
</div>
@endsection
