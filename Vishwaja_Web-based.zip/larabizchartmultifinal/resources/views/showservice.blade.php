@extends('layouts.app')

@section('content')
<div class="row">
    <div class="col-md-8 col-md-offset-2">
        <div class="panel panel-default">
            <div class="panel-heading">{{$service->s_name}} <a href="/services" class="pull-right btn btn-default btn-xs">Go Back</a></div>

            <div class="panel-body">
              <ul class="list-group">
                <li class="list-group-item">Address: {{$service->s_address}}</li>
                <li class="list-group-item">Website: <a href="{{$service->s_website}}" target="_blank">{{$service->s_website}}</a></li>
                <li class="list-group-item">Email: {{$service->s_email}}</li>
                <li class="list-group-item">Phone: {{$service->s_phone}}</li>
              </ul>
              <hr>
              <div class="well">
                {{$service->s_bio}}
              </div>
            </div>
        </div>
    </div>
</div>
@endsection
