@extends('layouts.app')

@section('content')
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Dashboard <span class="pull-right"><a href="/listings/create" class="btn btn-success btn-xs">Add Listing</a></span></div>

                <div class="panel-body">
                    <h3>Your Listings</h3>
                    @if(count($listings))
                      <table class="table table-striped">
                        <tr>
                          <th>Company</th>
                          <th></th>
                          <th></th>
                        </tr>
                        @foreach($listings as $listing)
                          <tr>
                            <td>{{$listing->name}}</td>
                            <td><a class="pull-right btn btn-default" href="/listings/{{$listing->id}}/edit">Edit</a></td>
                            <td>
                              {!!Form::open(['action' => ['ListingsController@destroy', $listing->id],'method' => 'POST', 'class' => 'pull-left', 'onsubmit' => 'return confirm("Are you sure?")'])!!}
                                {{Form::hidden('_method', 'DELETE')}}
                                {{Form::bsSubmit('Delete', ['class' => 'btn btn-danger'])}}
                              {!! Form::close() !!}
                            </td>
                          </tr>
                        @endforeach
                      </table>
                    @endif
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Your Fundings <span class="pull-right"><a href="/fundings/create" class="btn btn-success btn-xs">Add Funding</a></span></div>

                <div class="panel-body">
                    
                    @if(count($fundings))
                      <table class="table table-striped">
                        <tr>
                          <th>Funding Project</th>
                          <th></th>
                          <th></th>
                        </tr>
                        @foreach($fundings as $funding)
                          <tr>
                            <td>{{$funding->f_title_project}}</td>
                            <td><a class="pull-right btn btn-default" href="/fundings/{{$funding->id}}/edit">Edit</a></td>
                            <td>
                              {!!Form::open(['action' => ['FundingsController@destroy', $funding->id],'method' => 'POST', 'class' => 'pull-left', 'onsubmit' => 'return confirm("Are you sure?")'])!!}
                                {{Form::hidden('_method', 'DELETE')}}
                                {{Form::bsSubmit('Delete', ['class' => 'btn btn-danger'])}}
                              {!! Form::close() !!}
                            </td>
                          </tr>
                        @endforeach
                      </table>
                    @endif
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Your Qualifications <span class="pull-right"><a href="/qualifications/create" class="btn btn-success btn-xs">Add Qualification</a></span></div>

                <div class="panel-body">
                    
                    @if(count($qualifications))
                      <table class="table table-striped">
                        <tr>
                          <th>Organisation</th>
                          <th></th>
                          <th></th>
                        </tr>
                        @foreach($qualifications as $qualification)
                          <tr>
                            <td>{{$qualification->q_organisation}}</td>
                            <td><a class="pull-right btn btn-default" href="/qualifications/{{$qualification->id}}/edit">Edit</a></td>
                            <td>
                              {!!Form::open(['action' => ['QualificationsController@destroy', $qualification->id],'method' => 'POST', 'class' => 'pull-left', 'onsubmit' => 'return confirm("Are you sure?")'])!!}
                                {{Form::hidden('_method', 'DELETE')}}
                                {{Form::bsSubmit('Delete', ['class' => 'btn btn-danger'])}}
                              {!! Form::close() !!}
                            </td>
                          </tr>
                        @endforeach
                      </table>
                    @endif
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Your Services<span class="pull-right"><a href="/services/create" class="btn btn-success btn-xs">Add Service</a></span></div>

                <div class="panel-body">
                    
                    @if(count($services))
                      <table class="table table-striped">
                        <tr>
                          <th>Role/Title</th>
                          <th></th>
                          <th></th>
                        </tr>
                        @foreach($services as $service)
                          <tr>
                            <td>{{$service->s_role_title}}</td>
                            <td><a class="pull-right btn btn-default" href="/services/{{$service->id}}/edit">Edit</a></td>
                            <td>
                              {!!Form::open(['action' => ['ServicesController@destroy', $service->id],'method' => 'POST', 'class' => 'pull-left', 'onsubmit' => 'return confirm("Are you sure?")'])!!}
                                {{Form::hidden('_method', 'DELETE')}}
                                {{Form::bsSubmit('Delete', ['class' => 'btn btn-danger'])}}
                              {!! Form::close() !!}
                            </td>
                          </tr>
                        @endforeach
                      </table>
                    @endif
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Your Works <span class="pull-right"><a href="/works/create" class="btn btn-success btn-xs">Add Work</a></span></div>

                <div class="panel-body">
                    
                    @if(count($works))
                      <table class="table table-striped">
                        <tr>
                          <th>Work Journal</th>
                          <th></th>
                          <th></th>
                        </tr>
                        @foreach($works as $work)
                          <tr>
                            <td>{{$work->w_journal_title}}</td>
                            <td><a class="pull-right btn btn-default" href="/works/{{$work->id}}/edit">Edit</a></td>
                            <td>
                              {!!Form::open(['action' => ['WorksController@destroy', $work->id],'method' => 'POST', 'class' => 'pull-left', 'onsubmit' => 'return confirm("Are you sure?")'])!!}
                                {{Form::hidden('_method', 'DELETE')}}
                                {{Form::bsSubmit('Delete', ['class' => 'btn btn-danger'])}}
                              {!! Form::close() !!}
                            </td>
                          </tr>
                        @endforeach
                      </table>
                    @endif
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Your Employments <span class="pull-right"><a href="/employments/create" class="btn btn-success btn-xs">Add Employment</a></span></div>

                <div class="panel-body">
                    
                    @if(count($employments))
                      <table class="table table-striped">
                        <tr>
                          <th>Role/Title</th>
                          <th></th>
                          <th></th>
                        </tr>
                        @foreach($employments as $employment)
                          <tr>
                            <td>{{$employment->e_role_title}}</td>
                            <td><a class="pull-right btn btn-default" href="/employments/{{$employment->id}}/edit">Edit</a></td>
                            <td>
                              {!!Form::open(['action' => ['EmploymentsController@destroy', $employment->id],'method' => 'POST', 'class' => 'pull-left', 'onsubmit' => 'return confirm("Are you sure?")'])!!}
                                {{Form::hidden('_method', 'DELETE')}}
                                {{Form::bsSubmit('Delete', ['class' => 'btn btn-danger'])}}
                              {!! Form::close() !!}
                            </td>
                          </tr>
                        @endforeach
                      </table>
                    @endif
                </div>
            </div>
        </div>
    </div>

@endsection
