@extends('layouts.app')

@section('content')
<div class="row">
    <div class="col-md-8 col-md-offset-2">
        <div class="panel panel-default">
            <div class="panel-heading">Edit Qualification <a href="/dashboard" class="pull-right btn btn-default btn-xs">Go Back</a></div>

            <div class="panel-body">
              {!!Form::open(['action' => ['QualificationsController@update', $qualification->id],'method' => 'POST'])!!}


                    {{Form::bsText('q_organisation',$qualification->q_organisation,['placeholder' => 'Organisation','label'=>'Organisation'])}}

                    {{Form::bsText('q_city',$qualification->q_city,['placeholder' => 'City','label'=>'City'])}}

                    {{Form::bsText('q_state_region',$qualification->q_state_region,['placeholder' => 'State/Region','label'=>'State/Region'])}}

                    <p><strong>Country</strong></p>
                    {{Form::select('q_country',['India'=>'India','USA'=>'USA','England'=>'England','South Africa'=>'South Africa','Russia'=>'Russia','Malaysia'=>'Malaysia','Other'=>'Other'],$qualification->q_country,['placeholder'=>'Country','label'=>'Country'])}}

                    {{Form::bsText('q_department',$qualification->q_department,['placeholder' => 'Department','label'=>'Department'])}}

                    {{Form::bsText('q_role_title',$qualification->q_role_title,['placeholder' => 'Role/Title','label'=>'Role/Title'])}}

                    {{Form::bsText('q_url',$qualification->q_url,['placeholder' => 'URL','label'=>'URL'])}}

                    <p><strong>Start Date</strong></p>
                    {{Form::date('q_start_date',$qualification->q_start_date,['placeholder' => 'Start Date','label'=>'Start Date'])}}

                    <p><strong>End Date</strong></p>
                    {{Form::date('q_end_date',$qualification->q_end_date,['placeholder' => 'End Date','label'=>'End Date'])}}



                {{Form::hidden('_method', 'PUT')}}
                {{Form::bsSubmit('submit')}}
              {!! Form::close() !!}
            </div>
        </div>
    </div>
</div>
@endsection
