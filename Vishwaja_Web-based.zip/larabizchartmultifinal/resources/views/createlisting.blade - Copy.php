@extends('layouts.app')

@section('content')
<div class="row">
    <div class="col-md-8 col-md-offset-2">
        <div class="panel panel-default">
            <div class="panel-heading">Create Listing <a href="/dashboard" class="pull-right btn btn-default btn-xs">Go Back</a></div>

            <div class="panel-body">

                 <p>
                  <a class="btn btn-primary" data-toggle="collapse" href="#collapseExample1" role="button" aria-expanded="false" aria-controls="collapseExample1">
                    Link with href
                  </a>
                  <a class="btn btn-primary" data-toggle="collapse" href="#collapseExample2" role="button" aria-expanded="false" aria-controls="collapseExample2">
                    Link with href
                  </a>
                  <a class="btn btn-primary" data-toggle="collapse" href="#collapseExample3" role="button" aria-expanded="false" aria-controls="collapseExample3">
                    Link with href
                  </a>
                  <button class="btn btn-primary" type="button" data-toggle="collapse" data-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
                    Button with data-target
                  </button>
                </p>
                 {!!Form::open(['action' => 'ListingsController@store','method' => 'POST'])!!}
                <div class="collapse" id="collapseExample1">
                  <div class="card card-body">
                    

                {{Form::bsText('name','',['placeholder' => 'Company Name'])}}
                {{Form::bsText('website','',['placeholder' => 'Company Website'])}}
                   </div>
                </div>
                 <div class="collapse" id="collapseExample2">
                  <div class="card card-body">
                    

                {{Form::bsText('email','',['placeholder' => 'Contact Email'])}}
                {{Form::bsText('phone','',['placeholder' => 'Contact Phone'])}}
                   </div>
                </div>
                <div class="collapse" id="collapseExample3">
                  <div class="card card-body">
                    

                 {{Form::bsText('address','',['placeholder' => 'Business Address'])}}
                {{Form::bsTextArea('bio','',['placeholder' => 'About This Business'])}}
                </div>
              
              
               
                {{Form::bsSubmit('submit')}}
              {!! Form::close() !!}


               


              
            </div>
        </div>
    </div>
</div>
@endsection
