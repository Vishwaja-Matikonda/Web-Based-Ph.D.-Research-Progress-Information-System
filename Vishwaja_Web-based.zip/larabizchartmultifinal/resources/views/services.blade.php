@extends('layouts.app')

@section('content')
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Latest Services</div>

                <div class="panel-body">
                    @if(count($services))
                        <ul class="list-group">
                          @foreach($services as $service)
                            <li class="list-group-item"><a href="/services/{{$service->id}}">{{$service->s_name}}</a></li>
                          @endforeach
                        </ul>
                    @else
                      <p>No Services Found</p>
                    @endif
                </div>
            </div>
        </div>
    </div>
@endsection
