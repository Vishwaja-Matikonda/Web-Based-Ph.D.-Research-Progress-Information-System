@extends('layouts.app')

@section('content')
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Latest Funding News</div>

                <div class="panel-body">
                    @if(count($fundings))
                        <table class="table table-striped">
                        <tr>
                          <th>Grant No.</th>
                          <th>Type</th>
                          <th>Project Title</th>
                          <th>Amount</th>
                        </tr>
                        @foreach($fundings as $funding)
                          <tr>
                            <td>{{$funding->f_grant_number}}</td>
                            <td>{{$funding->f_type}}</td>
                            <td>{{$funding->f_title_project}}</td>
                            <td>{{$funding->f_amount}}</td>
                          </tr>
                        @endforeach
                      </table>
                    @else
                      <p>No Fundings Found</p>
                    @endif
                </div>
            </div>
        </div>
    </div>
@endsection
