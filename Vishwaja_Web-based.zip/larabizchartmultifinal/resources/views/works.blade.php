@extends('layouts.app')

@section('content')
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Latest Works</div>

                <div class="panel-body">
                    @if(count($works))
                        <ul class="list-group">
                          @foreach($works as $work)
                            <li class="list-group-item"><a href="/works/{{$work->id}}">{{$work->w_name}}</a></li>
                          @endforeach
                        </ul>
                    @else
                      <p>No Works Found</p>
                    @endif
                </div>
            </div>
        </div>
    </div>
@endsection
