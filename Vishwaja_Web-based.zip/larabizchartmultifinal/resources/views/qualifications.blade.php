@extends('layouts.app')

@section('content')
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Latest Qualifications</div>

                <div class="panel-body">
                    @if(count($qualifications))
                        <ul class="list-group">
                          @foreach($qualifications as $qualification)
                            <li class="list-group-item"><a href="/qualifications/{{$qualification->id}}">{{$qualification->q_name}}</a></li>
                          @endforeach
                        </ul>
                    @else
                      <p>No Qualifications Found</p>
                    @endif
                </div>
            </div>
        </div>
    </div>
@endsection
