@extends('layouts.app')

@section('content')
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                
              @if($users))
              @foreach($users as $user)
                <div class="panel-body">
                    
                   
                      <table class="table table-striped">
                        <tr>
                          <h4>Name: {{$user->name}}</h4>
                        </tr>
                        <tr>
                          <h4>Email: {{$user->email}}</h4>
                        </tr>
                        <tr><span class="pull-right"><a href="{{action('DashboardController@downloadPDF', $user->id)}}" class="btn btn-success btn-xs">Download Profile</a></span></tr>
                     
                      </table>
                   
                </div>
                <hr>
                @endforeach
                @endif
            </div>
        </div>
    </div>

@endsection
