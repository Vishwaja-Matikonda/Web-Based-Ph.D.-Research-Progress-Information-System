@extends('layouts.app')

@section('content')
<div class="row">
    <div class="col-md-8 col-md-offset-2">
        <div class="panel panel-default">
            <div class="panel-heading">{{$employment->e_name}} <a href="/employments" class="pull-right btn btn-default btn-xs">Go Back</a></div>

            <div class="panel-body">
              <ul class="list-group">
                <li class="list-group-item">Address: {{$employment->e_address}}</li>
                <li class="list-group-item">Website: <a href="{{$employment->e_website}}" target="_blank">{{$employment->e_website}}</a></li>
                <li class="list-group-item">Email: {{$employment->e_email}}</li>
                <li class="list-group-item">Phone: {{$employment->e_phone}}</li>
              </ul>
              <hr>
              <div class="well">
                {{$employment->e_bio}}
              </div>
            </div>
        </div>
    </div>
</div>
@endsection
