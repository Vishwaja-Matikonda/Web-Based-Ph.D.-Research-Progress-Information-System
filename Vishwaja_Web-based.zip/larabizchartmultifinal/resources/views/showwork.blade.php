@extends('layouts.app')

@section('content')
<div class="row">
    <div class="col-md-8 col-md-offset-2">
        <div class="panel panel-default">
            <div class="panel-heading">{{$work->w_name}} <a href="/works" class="pull-right btn btn-default btn-xs">Go Back</a></div>

            <div class="panel-body">
              <ul class="list-group">
                <li class="list-group-item">Address: {{$work->w_address}}</li>
                <li class="list-group-item">Website: <a href="{{$work->w_website}}" target="_blank">{{$work->w_website}}</a></li>
                <li class="list-group-item">Email: {{$work->w_email}}</li>
                <li class="list-group-item">Phone: {{$work->w_phone}}</li>
              </ul>
              <hr>
              <div class="well">
                {{$work->w_bio}}
              </div>
            </div>
        </div>
    </div>
</div>
@endsection
