@extends('layouts.app')

@section('content')
<div class="row">
    <div class="col-md-8 col-md-offset-2">
        <div class="panel panel-default">
            <div class="panel-heading">Create Service <a href="/dashboard" class="pull-right btn btn-default btn-xs">Go Back</a></div>

            <div class="panel-body">
              {!!Form::open(['action' => 'ServicesController@store','method' => 'POST'])!!}

                {{Form::bsText('s_organisation','',['placeholder' => 'Organisation','label'=>'Organisation'])}}

                {{Form::bsText('s_city','',['placeholder' => 'City','label'=>'City'])}}

                {{Form::bsText('s_state_region','',['placeholder' => 'State/Region','label'=>'State/Region'])}}

                <p><strong>Country</strong></p>
                {{Form::select('s_country',['India'=>'India','USA'=>'USA','England'=>'England','South Africa'=>'South Africa','Russia'=>'Russia','Malaysia'=>'Malaysia','Other'=>'Other'],null,['placeholder'=>'Country','label'=>'Country'])}}

                {{Form::bsText('s_department','',['placeholder' => 'Department','label'=>'Department'])}}

                {{Form::bsText('s_role_title','',['placeholder' => 'Role/Title','label'=>'Role/Title'])}}

                {{Form::bsText('s_url','',['placeholder' => 'URL','label'=>'URL'])}}

                <p><strong>Start Date</strong></p>
                {{Form::date('s_start_date','',['placeholder' => 'Start Date','label'=>'Start Date'])}}

                <p><strong>End Date</strong></p>
                {{Form::date('s_end_date','',['placeholder' => 'End Date','label'=>'End Date'])}}


                {{Form::bsSubmit('submit')}}
              {!! Form::close() !!}
            </div>
        </div>
    </div>
</div>
@endsection
