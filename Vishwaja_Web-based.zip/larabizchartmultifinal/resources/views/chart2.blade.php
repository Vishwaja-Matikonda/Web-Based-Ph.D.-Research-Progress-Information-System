@extends('layouts.app')

@section('content')
     <div class="row">
        <h3>Analytics with Static Data-Development is in progress</h3>
    </div>


    <div id="pop_div"></div>

    @areachart('Population', 'pop_div')

    <div id="perf_div"></div>
    @columnchart('Fundings', 'perf_div')
@endsection
