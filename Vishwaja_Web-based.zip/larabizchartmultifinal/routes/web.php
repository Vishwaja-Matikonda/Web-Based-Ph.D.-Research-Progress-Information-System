<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/list', 'ListingsController@index');
Route::get('/', 'FundingsController@index');

Auth::routes();
Route::resource('listings', 'ListingsController');
Route::resource('fundings', 'FundingsController');
Route::resource('qualifications', 'QualificationsController');
Route::resource('services', 'ServicesController');
Route::resource('works', 'WorksController');
Route::resource('employments', 'EmploymentsController');

Route::get('/dashboard', 'DashboardController@index');
Route::get('/profile', 'DashboardController@profile');
Route::get('/chart', 'DashboardController@chart');
Route::get('/chart2', 'DashboardController@chart2');
Route::get('/downloadPDF/{id}','DashboardController@downloadPDF');
Route::get('/admin', 'DashboardController@admin');

